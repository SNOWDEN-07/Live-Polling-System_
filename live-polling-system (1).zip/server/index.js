const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

let currentQuestion = null;
let responses = {};
let students = new Set();

io.on("connection", (socket) => {
  console.log("Client connected:", socket.id);

  socket.on("register-student", (name) => {
    students.add(name);
    socket.data.name = name;
  });

  socket.on("create-question", (question) => {
    if (!currentQuestion || Object.keys(responses).length === students.size) {
      currentQuestion = question;
      responses = {};
      io.emit("new-question", question);

      setTimeout(() => {
        io.emit("poll-results", responses);
        currentQuestion = null;
      }, 60000);
    }
  });

  socket.on("submit-answer", ({ name, answer }) => {
    responses[name] = answer;
    if (Object.keys(responses).length === students.size) {
      io.emit("poll-results", responses);
      currentQuestion = null;
    }
  });

  socket.on("disconnect", () => {
    if (socket.data.name) {
      students.delete(socket.data.name);
    }
  });
});

server.listen(4000, () => {
  console.log("Server is running on port 4000");
});