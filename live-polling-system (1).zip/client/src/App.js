import React, { useState, useEffect } from "react";
import io from "socket.io-client";
const socket = io(process.env.REACT_APP_BACKEND_URL);

function App() {
  const [role, setRole] = useState(null);
  const [name, setName] = useState("");
  const [question, setQuestion] = useState("");
  const [activeQuestion, setActiveQuestion] = useState(null);
  const [answer, setAnswer] = useState("");
  const [results, setResults] = useState(null);

  useEffect(() => {
    socket.on("new-question", (q) => {
      setActiveQuestion(q);
      setResults(null);
    });
    socket.on("poll-results", (res) => {
      setResults(res);
    });
    return () => {
      socket.off("new-question");
      socket.off("poll-results");
    };
  }, []);

  const handleStudentJoin = () => {
    socket.emit("register-student", name);
    setRole("student");
  };

  const submitAnswer = () => {
    socket.emit("submit-answer", { name, answer });
    setAnswer("");
  };

  const createQuestion = () => {
    socket.emit("create-question", question);
    setQuestion("");
  };

  if (!role) {
    return (
      <div className="p-4">
        <h2>Select your role:</h2>
        <button onClick={() => setRole("teacher")}>I'm a Teacher</button>
        <br />
        <input
          type="text"
          placeholder="Enter student name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <button onClick={handleStudentJoin}>Join as Student</button>
      </div>
    );
  }

  if (role === "teacher") {
    return (
      <div className="p-4">
        <h2>Teacher Dashboard</h2>
        <input
          type="text"
          placeholder="Enter question"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
        />
        <button onClick={createQuestion}>Send Question</button>
        {results && (
          <div>
            <h3>Results</h3>
            {Object.entries(results).map(([k, v]) => (
              <div key={k}>{k}: {v}</div>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="p-4">
      <h2>Welcome, {name}</h2>
      {activeQuestion ? (
        <div>
          <p><strong>{activeQuestion}</strong></p>
          <input
            type="text"
            placeholder="Your answer"
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
          />
          <button onClick={submitAnswer}>Submit</button>
        </div>
      ) : (
        <p>No active question.</p>
      )}
      {results && (
        <div>
          <h3>Results</h3>
          {Object.entries(results).map(([k, v]) => (
            <div key={k}>{k}: {v}</div>
          ))}
        </div>
      )}
    </div>
  );
}

export default App;