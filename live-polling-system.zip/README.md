# 📊 Live Polling System

A real-time polling web application built with **React**, **Express.js**, and **Socket.io**. It supports two user roles: **Teacher** (who can create questions and view results) and **Student** (who can answer questions and see live results). Includes a real-time **chat popup** for interaction.

### 🔗 [Figma Design](https://www.figma.com/design/uhinheFgWssbxvlI7wtf59/Intervue-Assigment--Poll-system?node-id=0-1)

---

## 🧑‍🏫 Features

### Teacher
- Create and broadcast poll questions
- View live poll results
- Ask a new question only after all students have answered or time expires

### Student
- Enter unique name per tab
- Receive and answer polls in real time
- View live results after submission or timeout
- 60-second countdown per question

### Common
- Real-time updates with Socket.io
- Chat popup for teacher-student messaging
- Clean UI matching Figma design

---

## 🛠 Tech Stack

- **Frontend**: React, Tailwind CSS (optional)
- **Backend**: Node.js, Express.js, Socket.io
- **Hosting**: Netlify (Frontend), Render/Heroku (Backend)

---

## 🚀 Getting Started

### 1. Clone the Repository
```bash
git clone https://github.com/yourusername/live-polling-system.git
cd live-polling-system
```

### 2. Setup Backend
```bash
cd backend
npm install
node index.js
# or use nodemon
```

### 3. Setup Frontend
```bash
cd frontend
npm install
npm start
```

Make sure the backend runs on `http://localhost:5000` for local dev.

---

## 🌍 Deployment

### Frontend (Netlify)
- Push frontend folder to GitHub
- Connect repo to Netlify
- Set build command: `npm run build`
- Set publish directory: `build`

### Backend (Render)
- Push backend folder to GitHub
- Create a new Render Web Service
- Set start command: `node index.js`
- Add CORS for your frontend domain

---

## 📸 UI Preview

> ![UI Screenshot](https://via.placeholder.com/800x400.png?text=Insert+Screenshot+Here)

---

## 📦 Folder Structure
```
/frontend
  - src/App.js
  - public/
  - package.json

/backend
  - index.js
  - package.json
```

---

## 📬 Feedback or Contributions
Pull requests are welcome. For major changes, open an issue first to discuss what you would like to change.